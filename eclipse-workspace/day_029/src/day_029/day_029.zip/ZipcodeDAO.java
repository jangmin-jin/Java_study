package day_029;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ZipcodeDAO {
	// CRUD 작업을 실시
	private Connection conn;
	
	// 생성자
	public ZipcodeDAO() {
		String url = "jdbc:mysql://localhost:3306/sample";
		String user = "root";
		String password = "123456";

		try {
			Class.forName("org.mariadb.jdbc.Driver");
			this.conn = DriverManager.getConnection(url, user, password);
		} catch (ClassNotFoundException e) {
			System.out.println( "에러 : " + e.getMessage() );
		} catch (SQLException e) {
			System.out.println( "에러 : " + e.getMessage() );
		} 
	}
	
	public ArrayList<ZipcodeTo> listSido(){
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		ArrayList<ZipcodeTo> sidos = new ArrayList<ZipcodeTo>();
		
		try {
			String sql = "select distinct sido from zipcode";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			// ZipcodeTo의 getter setter를 이용하여 데이터 주고받음
			ZipcodeTo to = new ZipcodeTo();
			to.setSido("시도");
			sidos.add(to);
			
			// 
			while(rs.next()) {
				to = new ZipcodeTo();
				to.setSido(rs.getString("sido"));
				sidos.add(to);
			}
		} catch (SQLException e) {
			System.out.println( "에러 : " + e.getMessage() );
		} finally {
			if(rs != null) try {rs.close();} catch(SQLException e) {};
			if(pstmt != null) try {pstmt.close();} catch(SQLException e) {};
			if(conn != null) try {conn.close();} catch(SQLException e) {};
		}
		
		return sidos;
	}
}