package project;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPasswordField;

public class LoginDlg extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JPasswordField passwordField;
	
	// 아이디와 비밀번호
	public String loginID = "";
	public String loginPW = "";
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			LoginDlg dialog = new LoginDlg();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public LoginDlg() {
		setTitle("로그인");
		setBounds(100, 100, 280, 180);
		setLocationRelativeTo(null);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("아이디");
			lblNewLabel.setBounds(12, 33, 51, 15);
			contentPanel.add(lblNewLabel);
		}
		{
			JLabel lblNewLabel = new JLabel("비밀번호");
			lblNewLabel.setBounds(12, 69, 51, 15);
			contentPanel.add(lblNewLabel);
		}
		{
			textField = new JTextField();
			textField.setBounds(71, 27, 160, 21);
			contentPanel.add(textField);
			textField.setColumns(10);
		}
		{
			passwordField = new JPasswordField();
			passwordField.setBounds(71, 66, 160, 21);
			contentPanel.add(passwordField);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton btnNewButton = new JButton("회원가입");
				btnNewButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						SignUpDlg signUpDlg = new SignUpDlg();
						signUpDlg.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
						signUpDlg.setModal(true);
						signUpDlg.setVisible(true);
						
					}
				});
				buttonPane.add(btnNewButton);
			}
			{
				JButton okButton = new JButton("로그인");
				okButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						DataDAO dao = new DataDAO();
						
						String id = textField.getText();
						String pw = new String(passwordField.getPassword());
						 System.out.println("입력한 ID : " + id);
						 System.out.println("입력한 PW : " +pw);
						
						// 로그인 결과 체크
						int idcheck = dao.logInCheck(id, pw);
						 System.out.println("로그인Dlg 결과 : " + idcheck);
						
						 // 검사 로직은 좀더 생각해봐야함 !!!!
						switch(idcheck){
							case 0 : 
								loginID = id;
								loginPW = pw;
								LoginDlg.this.dispose();
								break;
							case 1 :
//								JOptionPane.showMessageDialog(LoginDlg.this, "가입되지 않은 ID입니다.",
//										"로그인 오류", JOptionPane.ERROR_MESSAGE);
								JOptionPane.showMessageDialog(LoginDlg.this, "로그인 정보를 다시 확인해주세요.",
										"로그인 오류", JOptionPane.ERROR_MESSAGE);
								break;
							case 2 :
//								JOptionPane.showMessageDialog(LoginDlg.this, "비밀번호를 다시 입력해 주세요.",
//										"로그인 오류", JOptionPane.ERROR_MESSAGE);
								JOptionPane.showMessageDialog(LoginDlg.this, "로그인 정보를 다시 확인해주세요.",
										"로그인 오류", JOptionPane.ERROR_MESSAGE);
								break;
							case 3 :
//								JOptionPane.showMessageDialog(LoginDlg.this, "가입되지 않은 ID입니다.",
//										"로그인 오류", JOptionPane.ERROR_MESSAGE);
								JOptionPane.showMessageDialog(LoginDlg.this, "로그인 정보를 다시 확인해주세요.",
										"로그인 오류", JOptionPane.ERROR_MESSAGE);
								break;
						}
						
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("취소");
				cancelButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						
						LoginDlg.this.dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

}
