package project;

import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.swing.JLabel;
import javax.swing.JTextField;

public class TodoListMain extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JButton btnInsert;
	private JButton btnModify;
	private JButton btnDelete;
	private JButton btnComplete;
	private JButton btnTodo;
	private JButton btnComTodo;
	private JButton btnDelTodo;
	private int listSelect = 0;
	private int buttonType = 0;
	private String id = "";
	private String pw = "";
	private JTextField textFieldNowLoginId;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TodoListMain frame = new TodoListMain();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TodoListMain() {
		setTitle("Todo 관리");
		setFont(new Font("돋움", Font.PLAIN, 12));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 768);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		btnTodo = new JButton("할일 목록");
		btnTodo.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				// 할일 목록
				listSelect = 0;
				// 버튼 활성화 유무 결정
				btnInsert.setEnabled(true);
				btnInsert.setText("추가");
				btnModify.setEnabled(true);
				btnModify.setText("수정");
				btnDelete.setEnabled(true);
				btnDelete.setText("삭제");
				btnComplete.setEnabled(true);
				btnComplete.setText("완료");
				
				
				if(id.equals("")) {
					JOptionPane.showMessageDialog(TodoListMain.this, "로그인 해주세요.",
							"로그인 정보 없음", JOptionPane.PLAIN_MESSAGE);
				}else {
					System.out.println("로그인 하셨군요 ?");
					// 할일목록 listType
					// int listType = 0;
					table.setModel(new CustomTodoModel(id, listSelect));
				}
				
//				table.setModel(new CustomTodoModel(id));
				
			}
		});
		btnTodo.setBounds(158, 10, 120, 40);
		contentPane.add(btnTodo);
		
		btnComTodo = new JButton("완료 목록");
		btnComTodo.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				// 할일 목록
				listSelect = 1;
				// 버튼 활성화 유무 결정
				btnInsert.setEnabled(true);
				btnInsert.setText("복구");
				btnModify.setEnabled(false);
				btnModify.setText("수정");
				btnDelete.setEnabled(true);
				btnDelete.setText("삭제");
				btnComplete.setEnabled(false);
				btnComplete.setText("완료");
				
				if(id.equals("")) {
					JOptionPane.showMessageDialog(TodoListMain.this, "로그인 해주세요.",
							"로그인 정보 없음", JOptionPane.PLAIN_MESSAGE);
				}else {
					System.out.println("로그인 하셨군요 ?");
					// 완료목록 listType
					// int listType = 1;
					table.setModel(new CustomTodoModel(id, listSelect));
				}
				
			}
		});
		btnComTodo.setBounds(290, 10, 120, 40);
		contentPane.add(btnComTodo);
		
		btnDelTodo = new JButton("삭제 목록");
		btnDelTodo.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				// 할일 목록
				listSelect = 2;
				// 버튼 활성화 유무 결정
				btnInsert.setEnabled(true);
				btnInsert.setText("복구");
				btnModify.setEnabled(false);
				btnModify.setText("수정");
				btnDelete.setEnabled(true);
				btnDelete.setText("완전삭제");
				btnComplete.setEnabled(false);
				btnComplete.setText("완료");
				
				if(id.equals("")) {
					JOptionPane.showMessageDialog(TodoListMain.this, "로그인 해주세요.",
							"로그인 정보 없음", JOptionPane.PLAIN_MESSAGE);
				}else {
					System.out.println("로그인 하셨군요 ?");
					// 삭제목록 listType
					// int listType = 2;
					table.setModel(new CustomTodoModel(id, listSelect));
				}
				
			}
		});
		btnDelTodo.setBounds(422, 10, 120, 40);
		contentPane.add(btnDelTodo);
		
		JButton btnLogin = new JButton("로그인");
		btnLogin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				LoginDlg loginDlg = new LoginDlg();
				loginDlg.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				loginDlg.setModal(true);
				loginDlg.setVisible(true);
				
				id = loginDlg.loginID;
				pw = loginDlg.loginPW;
				
				textFieldNowLoginId.setText(id);
				
				// 할일목록 listType
				// int listType = 0;
				table.setModel(new CustomTodoModel(id, listSelect));
				
				// System.out.println("로그인 창 종료후 넘어온 ID : " + id);
				// System.out.println("로그인 창 종료후 넘어온 PW : " + pw);
			}
		});
		btnLogin.setBounds(749, 10, 120, 40);
		contentPane.add(btnLogin);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(158, 78, 711, 641);
		contentPane.add(scrollPane);
		
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
			},
			new String[] {
				"\uD560\uC77C", "\uC785\uB825 \uB0A0\uC9DC", "\uC644\uB8CC \uB0A0\uC9DC"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane.setViewportView(table);
		
		btnInsert = new JButton("추가");
		btnInsert.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				//추가 버튼 타입 : 0
				buttonType = 0;
				
				// 로그인 체크
				if(id.equals("")) {
					JOptionPane.showMessageDialog(TodoListMain.this, "로그인 해주세요.",
							"로그인 정보 없음", JOptionPane.PLAIN_MESSAGE);
				}else {
					String addTodo = null;
					addTodo = JOptionPane.showInputDialog(TodoListMain.this, "텍스트를 입력하세요",
							"추가", JOptionPane.QUESTION_MESSAGE) + " ";
					
					SimpleDateFormat format = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss" );
					Calendar time = Calendar.getInstance();
					String addTime = format.format(time.getTime());
					
					System.out.println("추가한 할일" + addTodo + "추가한 시간" + addTime);
					
					// null과 공백을 허용하지 않는다.
					if(addTodo != null) {
						if(addTodo.trim().equals("")) {
							return;
						}else {
							// 추가 버튼 타입 : 0
							// int buttonType = 0;
							DataDAO dao = new DataDAO();
							dao.addTodoList(id, addTodo, addTime);
							table.setModel(new CustomTodoModel(id, listSelect));
						}
					}
				}	
			}
		});
		btnInsert.setBounds(12, 78, 120, 40);
		contentPane.add(btnInsert);
		
		btnModify = new JButton("수정");
		btnModify.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(id.equals("")) {
					JOptionPane.showMessageDialog(TodoListMain.this, "로그인 해주세요.",
							"로그인 정보 없음", JOptionPane.PLAIN_MESSAGE);
				}else {
					String modifyTodo = null;
					
					String selectTodoList = (String)table.getValueAt(table.getSelectedRow(), 0);
					String selectTodoTime = (String)table.getValueAt(table.getSelectedRow(), 1);
					System.out.println(selectTodoList);
					System.out.println(selectTodoTime);
					
//					modifyTodo = JOptionPane.showInputDialog(TodoListMain.this, "수정할 텍스트를 입력하세요",
//							"수정", JOptionPane.QUESTION_MESSAGE);
//					System.out.println(modifyTodo);
				}
			}
		});
		btnModify.setBounds(12, 128, 120, 40);
		contentPane.add(btnModify);
		
		btnDelete = new JButton("삭제");
		btnDelete.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JOptionPane.showConfirmDialog(TodoListMain.this, "정말 삭제하시겠습니까?",
						"삭제확인", JOptionPane.WARNING_MESSAGE);
			}
		});
		btnDelete.setBounds(12, 178, 120, 40);
		contentPane.add(btnDelete);
		
		btnComplete = new JButton("완료");
		btnComplete.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JOptionPane.showMessageDialog(TodoListMain.this, "완료 목록으로 이동합니다.",
						"완료", JOptionPane.PLAIN_MESSAGE);
			}
		});
		btnComplete.setBounds(12, 287, 120, 40);
		contentPane.add(btnComplete);
		
		JLabel lblNewLabel = new JLabel("로그인 ID");
		lblNewLabel.setBounds(621, 10, 57, 15);
		contentPane.add(lblNewLabel);
		
		textFieldNowLoginId = new JTextField();
		textFieldNowLoginId.setEditable(false);
		textFieldNowLoginId.setBounds(621, 29, 116, 21);
		contentPane.add(textFieldNowLoginId);
		textFieldNowLoginId.setColumns(10);
	}
}