package project;

public class TodolistTO {
	private String id;
	private String todo;
	private String time;
	private String comtodo;
	private String comtime;
	private String deltodo;
	private String deltime;
	private Boolean comthis;
	private Boolean delthis;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTodo() {
		return todo;
	}
	public void setTodo(String todo) {
		this.todo = todo;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getComtodo() {
		return comtodo;
	}
	public void setComtodo(String comtodo) {
		this.comtodo = comtodo;
	}
	public String getComtime() {
		return comtime;
	}
	public void setComtime(String comtime) {
		this.comtime = comtime;
	}
	public String getDeltodo() {
		return deltodo;
	}
	public void setDeltodo(String deltodo) {
		this.deltodo = deltodo;
	}
	public String getDeltime() {
		return deltime;
	}
	public void setDeltime(String deltime) {
		this.deltime = deltime;
	}
	public Boolean getComthis() {
		return comthis;
	}
	public void setComthis(Boolean comthis) {
		this.comthis = comthis;
	}
	public Boolean getDelthis() {
		return delthis;
	}
	public void setDelthis(Boolean delthis) {
		this.delthis = delthis;
	}
	
}
